# Artist Job Board

## Getting Started

1. Create a `.env.local` file from `.env.example`
2. Fill in your Supabase project credentials
3. Run `npm install` and `npm run dev`

Deployed via [Vercel](https://vercel.com)

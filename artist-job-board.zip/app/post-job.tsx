import { useState, useEffect } from "react";
import { supabase } from "../utils/supabaseClient";
import { useRouter } from "next/router";

export default function PostJobPage() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [user, setUser] = useState(null);
  const [isArtist, setIsArtist] = useState(false);
  const router = useRouter();

  useEffect(() => {
    supabase.auth.getUser().then(async ({ data: { user } }) => {
      if (!user) router.push("/");
      else {
        setUser(user);
        const { data: profile } = await supabase
          .from("profiles")
          .select("role")
          .eq("id", user.id)
          .single();
        if (profile?.role === "artist" || profile?.role === "admin") {
          setIsArtist(true);
        } else {
          alert("Access denied. Only artists can post jobs.");
          router.push("/");
        }
      }
    });
  }, []);

  const handlePost = async () => {
    const { error } = await supabase.from("jobs").insert({
      title,
      description,
      created_by: user.id,
    });
    if (error) alert("Failed to post job");
    else {
      alert("Job posted successfully");
      router.push("/");
    }
  };

  if (!isArtist) return null;

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <h1 className="text-2xl font-bold mb-4">Post a New Job</h1>
      <input
        type="text"
        placeholder="Job Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        className="mb-2 p-2 border rounded w-full max-w-md"
      />
      <textarea
        placeholder="Job Description"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        className="mb-4 p-2 border rounded w-full max-w-md h-32"
      ></textarea>
      <button onClick={handlePost} className="bg-blue-600 text-white px-4 py-2 rounded">
        Post Job
      </button>
    </div>
  );
}

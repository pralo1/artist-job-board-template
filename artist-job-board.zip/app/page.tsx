import { useState, useEffect } from "react";
import { supabase } from "../utils/supabaseClient";
import { useRouter } from "next/router";

export default function HomePage() {
  const [user, setUser] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const router = useRouter();

  useEffect(() => {
    supabase.auth.getUser().then(async ({ data: { user } }) => {
      setUser(user);
      if (user) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("role")
          .eq("id", user.id)
          .single();
        setIsAdmin(profile?.role === "admin" || profile?.role === "artist");
      }
    });
  }, []);

  useEffect(() => {
    if (user) {
      fetchJobs();
    }
  }, [user]);

  const fetchJobs = async () => {
    let { data: jobs, error } = await supabase.from("jobs").select("*");
    if (!error) setJobs(jobs);
  };

  const handleLogin = async () => {
    const { error } = await supabase.auth.signInWithOAuth({ provider: "github" });
    if (error) alert("Login error");
  };

  const handleApply = async (jobId: string) => {
    const portfolio = prompt("Add a link to your portfolio:");
    const { error } = await supabase.from("applications").insert({ job_id: jobId, user_id: user.id, portfolio });
    if (error) alert("Failed to apply");
    else alert("Application submitted!");
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <h1 className="text-3xl font-bold mb-4">Exclusive Artist Job Board</h1>

      {!user ? (
        <button onClick={handleLogin} className="bg-black text-white px-4 py-2 rounded">
          Log In with GitHub
        </button>
      ) : (
        <>
          <p className="mb-4">Welcome, {user.email}</p>

          {isAdmin && (
            <button
              onClick={() => router.push("/post-job")}
              className="mb-6 bg-blue-600 text-white px-4 py-2 rounded"
            >
              Post a Job
            </button>
          )}

          <div className="w-full max-w-xl">
            {jobs.map((job) => (
              <div key={job.id} className="border p-4 mb-2 rounded shadow">
                <h2 className="text-xl font-semibold">{job.title}</h2>
                <p>{job.description}</p>
                <button
                  onClick={() => handleApply(job.id)}
                  className="mt-2 bg-green-600 text-white px-3 py-1 rounded"
                >
                  Apply
                </button>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
